;!function(window, NAME){
    //获取当前函数名
    Function.prototype.getName = function(){
        return this.name || this.toString().match(/function\s*([^(]*)\(/)[1]
    }
    //大写首字母
    String.prototype.firstUpperCase = function(){
        return this.replace(/\b(\w)(\w*)/g, function($0, $1, $2) {
            return $1.toUpperCase() + $2.toLowerCase();
        });
    }
    //HTTP 请求
    var httpGet = function(url, callback, option) {
        var request = null;
        if (window.XMLHttpRequest) {
            request = new XMLHttpRequest
        } else {
            request = new ActiveXObject("Microsoft.XMLHTTP")
        }
        if (request) {
            request.onreadystatechange = function() {
                if (request.readyState == 4) {
                    callback(option == "json" ? JSON.parse(request.responseText) : request.responseText)
                }
            };
            request.open("GET", url, true);
            request.send();
        }
    }
    /* URL参数 */
    var URLParams = function() {
        var obj = {}, search = window.location.search.slice(1);
        search.replace(/([^=]*)=([^&]*)&?/g, function(str, key, val){
            obj[key] = decodeURIComponent(val).replace(/</g, "&lt;").replace(/>/g, "&gt;");
        });
        obj.toString = function(){
            return search;
        };
        return obj;
    }

    var cmds = "authorize|";	//合法请求命令    

    var sdk = ({
        clientVersion: "1.0.0",     // 版本
        gameId: 0,                  // 游戏ID
        init: function() {
            var _self = this;
            // 获取URL上的初始化参数，如token，游戏ID
            _self.params = URLParams();
            // 监听message事件
            _self.getMessage();
            //初始化登录
            _self.postMessage({
                cmd: "authorize",
                data: JSON.parse(JSON.stringify(_self.params))
            }, "*");
            return _self;
        },
        postMessage: function(message, target) {
            // 发送消息
            window.top.postMessage(message, target)
        },

        /*------------------------登录相关------------------------*/
        authorize: function(cb){
             // 返回用户数据
             var _self = this;
             if(_self.userInfo && typeof cb == "function"){
                 cb(_self.userInfo);
             }else {
                 setTimeout(function(){
                     _self.authorize(cb);
                 },300)
             }
        },
        getAuthorize: function(d){
           // 接收用户数据
           this.userInfo = d;
        },
        /*-----------------------登录相关end----------------------*/

        getMessage: function(){
            //监听message事件并响应
			var _self = this;
			window.addEventListener('message', function(e){
                /* 调转函数和get函数的问题 */
                var fnName = "get" + e.data.cmd.firstUpperCase();
				if(_self[fnName]){
					_self[fnName](e.data.data);
				}else {
					console.log('未定义的消息: '+ e.data.cmd);
				}
			}, false);
		}
    }).init();
    window[NAME] = sdk;
}(window, "GUOPAN_h5_SDK");