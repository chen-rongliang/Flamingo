(function (root, factory) {
	if (typeof define === 'function' && define.amd) {
		// AMD
		define(['$'], factory);
	} else if (typeof exports === 'object') {
		// Node, CommonJS之类的
		module.exports = factory(require('$'));
	} else {
		// 浏览器全局变量(root 即 window)
		root.returnExports = factory(root.$, root._);
	}
}(this, function ($, _) {

	var platform = require("/src/js/platform");

	//合法请求命令
	var cmds = "authorize|";

	// 方法
	var sdk = {
		option: {},				// 参数
		platform: "Android",	// 平台类型
		frames: {},				// 创建的iframe集合
		init: function(option){
			var _self = this;
			// 接收初始化参数
			$.extend(this.option,option);
			// 监听message事件
			this.getMessage();
			// 设备平台
			this.platform = platform.isMobile ? (platform.isIos ? 'iOS' : ( platform.isAndroid ? 'Android' : 'other' )) : "PC";
			// 创建游戏iframe
			this.createFrame(this.option.name,this.option.game_url,'h5Game');
			
			return this;
		},
		createFrame : function(name, src, classes, callback) {
			// 创建iframe并记录 需要iframe的name、src属性，如果设置class，那么将创建一个可视的iframe，否则默认隐藏
			var _self = this;
			// 转换
			if (typeof classes === "function") {
				callback = classes;
				classes = "";
			}
			if(name && src){
				if (!this.frames[name]) {
					this.frames[name] = document.createElement("iframe");
					this.frames[name].name = name;
					this.frames[name].src = src;
					if(classes){
						this.frames[name].classList.add(classes)
					}else {
						this.frames[name].style.display = "none";
					}
					document.body.appendChild(this.frames[name]);
					this.frames[name].onload = function(){
						_self.frames[name].isLoad = true;
						console.log(name," is ready");
					}
				} else {
					this.frames[name].src = src
				}
			}else {
				console.error("参数缺失！");
			}
			
		},
		getPlatformType: function(){
			// 获取设备平台
			return this.platform;
		},
		postMessage: function(data, name) {
			// 发送消息
			var _self = this;
			//强制等待iframe加载后再发送消息，300ms为间隔做轮询
			if(_self.frames[name].isLoad){
				_self.frames[name].contentWindow.postMessage(data, "*");
			}else {
				setTimeout(function(){
					_self.postMessage(data, name);
				},300)
			}
		},
		// 发送账号信息
		authorize: function(d){
			var _self = this;
			console.log(d)
			// TODO token校验
			if(d.sign){
				_self.postMessage({
					cmd: "authorize",
					data: {
						code: 1,
						message: "获取用户信息成功",
						data: {
							platform: _self.platform,
							uin: 123456
						},
					}
				}, "h5Game");
			}else {
				_self.postMessage({
					cmd: "authorize",
					data: {
						code: 0,
						message: "参数有误！",
						data: {
							platform: _self.platform,
							uin: null
						},
					}
				}, "h5Game");
			}
		},
		testCmd: function(cmd){
			// 校验命令
			return cmds.indexOf(cmd)!=-1;
		},
		getMessage: function(){
			/* 接受请求 */
			var _self = this;
			window.addEventListener('message', function(e){
				if(_self.testCmd(e.data.cmd)){
					_self[e.data.cmd](e.data.data);
				}else {
					console.log('未定义的消息: '+ e.data.cmd);
				}
			}, false);
		}
	};

	return sdk;
}));