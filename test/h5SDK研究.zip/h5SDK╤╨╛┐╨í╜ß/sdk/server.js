var $ = require("$");
var SDKBridge = require("SDKBridge");

SDKBridge.init({
    name:"h5Game",
    game_url :"http://test-client/?source=guopan&guopanAppId=110538&game_uin=232D67B0FD470BD3&time=1510543739&gid=110538&sign=180d6a0d4866caa6d604388bf48fc5e1"
});